package com.najiha.exportoutreach;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.util.Base64;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;
import java.net.URLDecoder;

public class MainActivity extends Activity {
    private static final int FILE_CHOOSER_REQUEST = 701;
    private static final String START_URL = "https://crm.najihaglobal.com";
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setSupportMultipleWindows(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);
        webView.addJavascriptInterface(new DownloadBridge(), "NajihaDownload");

        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                installBlobDownloadSupport(view);
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                    FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                Intent intent = params.createIntent();
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                try {
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                } catch (ActivityNotFoundException e) {
                    filePathCallback = null;
                    Toast.makeText(MainActivity.this, "Aplikasi pemilih file tidak tersedia", Toast.LENGTH_LONG).show();
                    return false;
                }
                return true;
            }
        });

        webView.setDownloadListener(new DownloadListener() {
            @Override public void onDownloadStart(String url, String userAgent, String contentDisposition,
                    String mimeType, long contentLength) {
                try {
                    DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
                    request.setMimeType(mimeType);
                    String cookies = CookieManager.getInstance().getCookie(url);
                    if (cookies != null) request.addRequestHeader("Cookie", cookies);
                    request.addRequestHeader("User-Agent", userAgent);
                    request.setTitle("NAJIHA Export Outreach");
                    request.setDescription("Mengunduh file...");
                    request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,
                            safeDownloadName(contentDisposition, url));
                    ((DownloadManager) getSystemService(DOWNLOAD_SERVICE)).enqueue(request);
                    Toast.makeText(MainActivity.this, "Unduhan dimulai. Periksa folder Download.", Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Gagal mengunduh: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            }
        });

        if (savedInstanceState != null) webView.restoreState(savedInstanceState);
        else webView.loadUrl(START_URL);
    }

    private void installBlobDownloadSupport(WebView view) {
        String js = "(function(){if(window.__najihaBlobHook)return;window.__najihaBlobHook=true;" +
          "document.addEventListener('click',function(e){var a=e.target.closest('a[download]');" +
          "if(!a)return;var h=a.href||'';if(h.indexOf('blob:')!==0)return;e.preventDefault();" +
          "fetch(h).then(r=>r.blob()).then(b=>{var fr=new FileReader();fr.onloadend=function(){" +
          "var s=String(fr.result).split(',')[1]||'';window.NajihaDownload.save(s,a.download||'export.xlsx',b.type||'application/octet-stream');};fr.readAsDataURL(b);" +
          "}).catch(err=>console.log(err));},true);})();";
        view.evaluateJavascript(js, null);
    }

    private class DownloadBridge {
        @JavascriptInterface public void save(String base64, String filename, String mime) {
            runOnUiThread(() -> {
                try {
                    String safeName = filename == null ? "najiha-export.xlsx" : filename.replaceAll("[^a-zA-Z0-9._-]", "_");
                    if (!safeName.contains(".")) safeName += ".xlsx";
                    File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                    if (!dir.exists()) dir.mkdirs();
                    File out = new File(dir, safeName);
                    byte[] data = Base64.decode(base64, Base64.DEFAULT);
                    try (FileOutputStream fos = new FileOutputStream(out)) { fos.write(data); }
                    Toast.makeText(MainActivity.this, "File tersimpan: Download/" + safeName, Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Gagal menyimpan file", Toast.LENGTH_LONG).show();
                }
            });
        }
    }

    private static String safeDownloadName(String disposition, String url) {
        try {
            if (disposition != null && disposition.contains("filename=")) {
                String n = disposition.substring(disposition.indexOf("filename=") + 9).replace("\"", "").trim();
                if (!n.isEmpty()) return n.replaceAll("[^a-zA-Z0-9._-]", "_");
            }
            String path = Uri.parse(url).getLastPathSegment();
            return (path == null || path.isEmpty()) ? "download" : path.replaceAll("[^a-zA-Z0-9._-]", "_");
        } catch (Exception e) { return "download"; }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST) {
            if (filePathCallback == null) return;
            Uri[] results = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        }
    }

    @Override protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        webView.saveState(outState);
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (webView != null) { webView.destroy(); webView = null; }
        super.onDestroy();
    }
}
