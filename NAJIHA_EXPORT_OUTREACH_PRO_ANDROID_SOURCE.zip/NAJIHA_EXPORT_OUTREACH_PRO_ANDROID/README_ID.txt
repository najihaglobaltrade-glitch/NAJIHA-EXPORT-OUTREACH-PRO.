NAJIHA EXPORT OUTREACH PRO - ANDROID SOURCE

Isi project:
- Aplikasi Android WebView yang membuka https://crm.najihaglobal.com
- Login dan penyimpanan sesi menggunakan WebView cookies/local storage.
- Pemilih file Android untuk Import CSV dan Excel.
- Dukungan unduh file biasa dan ekspor Excel/CSV berbasis Blob.

PENTING:
Ini adalah SOURCE PROJECT Android Studio, bukan APK yang sudah dikompilasi.
Untuk menghasilkan APK:
1. Ekstrak ZIP ini di laptop Windows.
2. Install Android Studio dan Android SDK.
3. Buka Android Studio > Open > pilih folder NAJIHA_EXPORT_OUTREACH_PRO_ANDROID.
4. Tunggu Gradle Sync selesai.
5. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK debug biasanya tersedia di app/build/outputs/apk/debug/app-debug.apk.

Catatan:
- Aplikasi memerlukan internet.
- Pastikan website https://crm.najihaglobal.com sudah online dan HTTPS aktif.
- Impor CSV/XLSX bergantung pada fitur halaman web yang sudah terpasang.
- Untuk perubahan website, aplikasi akan memuat versi website terbaru saat dibuka.
